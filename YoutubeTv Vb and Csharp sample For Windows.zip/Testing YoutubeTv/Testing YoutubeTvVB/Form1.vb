﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim playList As New List(Of String)
        playList.Add("http://youtu.be/jHCY_YV7Ebs")
        playList.Add("http://youtu.be/0SdqOC8NA7s")
        playList.Add("http://youtu.be/5W_wd9Qf0IE")
        playList.Add("http://youtu.be/v9hdMSr6Duc")
        '//Add More video URL if needed  
        Dim detectURL As New YouTubeTv.DetectURL()
        For Each videoLink In playList
            If (detectURL.IsValidURL(detectURL.DetectURLLInk(videoLink)) = True) Then
                Dim TV As New YouTubeTv.YouTube(videoLink, "171", "111")
                Dim pictVideoImage As New PictureBox
                pictVideoImage.ImageLocation = TV.VideoImageUrl
                pictVideoImage.Size = New Size(Convert.ToInt32(TV.Width), Convert.ToInt32(TV.Height))
                pictVideoImage.Tag = TV.VideoUrl
                pictVideoImage.Cursor = Cursors.Hand
                AddHandler pictVideoImage.Click, AddressOf Image_click
                Me.flowLayoutPanel1.Controls.Add(pictVideoImage)
            Else
                ' //message to the user
                MessageBox.Show("Error")
            End If
        Next
    End Sub

    Public Sub Image_click(sender As Object, e As EventArgs)
        If TypeOf sender Is PictureBox Then
            Dim pict = CType(sender, PictureBox)
            Me.FlashPlayer.Movie = pict.Tag.ToString()
            Me.Text = "YouTubetv in Vb.Net " + pict.Tag.ToString()
        End If
    End Sub
End Class
