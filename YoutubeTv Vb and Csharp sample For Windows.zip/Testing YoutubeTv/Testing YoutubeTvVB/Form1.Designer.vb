﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.FlashPlayer = New AxShockwaveFlashObjects.AxShockwaveFlash()
        Me.flowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        CType(Me.FlashPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlashPlayer
        '
        Me.FlashPlayer.Enabled = True
        Me.FlashPlayer.Location = New System.Drawing.Point(0, 0)
        Me.FlashPlayer.Name = "FlashPlayer"
        Me.FlashPlayer.OcxState = CType(resources.GetObject("FlashPlayer.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlashPlayer.Size = New System.Drawing.Size(676, 394)
        Me.FlashPlayer.TabIndex = 0
        '
        'flowLayoutPanel1
        '
        Me.flowLayoutPanel1.AutoScroll = True
        Me.flowLayoutPanel1.Location = New System.Drawing.Point(1, 400)
        Me.flowLayoutPanel1.Name = "flowLayoutPanel1"
        Me.flowLayoutPanel1.Size = New System.Drawing.Size(676, 154)
        Me.flowLayoutPanel1.TabIndex = 3
        Me.flowLayoutPanel1.WrapContents = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(677, 558)
        Me.Controls.Add(Me.flowLayoutPanel1)
        Me.Controls.Add(Me.FlashPlayer)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "YouTubetv in Vb.net"
        CType(Me.FlashPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FlashPlayer As AxShockwaveFlashObjects.AxShockwaveFlash
    Private WithEvents flowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel

End Class
