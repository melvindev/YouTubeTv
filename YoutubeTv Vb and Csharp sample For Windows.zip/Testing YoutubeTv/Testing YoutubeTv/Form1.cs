﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testing_YoutubeTv
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        YouTubeTv.DetectURL detectURL = new YouTubeTv.DetectURL();
        private void Form1_Load(object sender, EventArgs e)
        {
            List<string> playList = new List<string>();
            playList.Add("http://youtu.be/jHCY_YV7Ebs");
            playList.Add("http://youtu.be/0SdqOC8NA7s");
            playList.Add("http://youtu.be/5W_wd9Qf0IE");
            playList.Add("http://youtu.be/v9hdMSr6Duc");
            //Add More video URL if needed  
            foreach (var videoLink in playList)
            {
                if (detectURL.IsValidURL(detectURL.DetectURLLInk(videoLink)) == true)
                {
                    YouTubeTv.YouTube TV = new YouTubeTv.YouTube(videoLink, "171", "111");
                    PictureBox pictVideoImage = new PictureBox();
                    pictVideoImage.ImageLocation = TV.VideoImageUrl;
                    pictVideoImage.Size = new Size(Convert.ToInt32(TV.Width), Convert.ToInt32(TV.Height));
                    pictVideoImage.Tag = TV.VideoUrl;
                    pictVideoImage.Click += new System.EventHandler(click_Image);
                    pictVideoImage.Cursor = Cursors.Hand;
                    this.flowLayoutPanel1.Controls.Add(pictVideoImage);                    
                }
                else
                {
                    //message to the user
                    MessageBox.Show("Error");
                }
            }
        }
        private void click_Image(object sender, EventArgs e)
        {
            if (sender is PictureBox)
            {
                PictureBox pict = (PictureBox)sender;
                this.FlashPlayer.Movie = (string)pict.Tag;
                this.Text="YouTubetv in C# "+ pict.Tag.ToString();
            }

        }

    }
}
