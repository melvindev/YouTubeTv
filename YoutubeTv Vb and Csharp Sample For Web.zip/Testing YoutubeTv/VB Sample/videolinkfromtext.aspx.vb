﻿Public Class videolinkfromtext
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.YoutubeScreenTV.Visible = False
        Me.VideoPosterImgBtn.Visible = False
    End Sub

    Dim detectURL As New YouTubeTv.DetectURL()

   

    Protected Sub loadVideobtn_Click(sender As Object, e As EventArgs) Handles loadVideobtn.Click
        If (detectURL.IsValidURL(detectURL.DetectURLLInk(Me.VideoLinktxt.Text)) = True) Then

            Dim TV As New YouTubeTv.YouTube(Me.VideoLinktxt.Text)
            Me.VideoPosterImgBtn.ImageUrl = TV.VideoImageUrl
            Me.VideoPosterImgBtn.Visible = True

        Else

            'message to the user
            Response.Write("Error")
        End If

    End Sub

    Protected Sub VideoPosterImgBtn_Click(sender As Object, e As ImageClickEventArgs) Handles VideoPosterImgBtn.Click
        If (detectURL.IsValidURL(detectURL.DetectURLLInk(Me.VideoLinktxt.Text)) = True) Then

            Dim TV As New YouTubeTv.YouTube(Me.VideoLinktxt.Text, "650px", "400px")
            Me.YoutubeScreenTV.Style.Add("width", TV.Width)
            Me.YoutubeScreenTV.Style.Add("height", TV.Height)
            Me.YoutubeScreenTV.Style.Add("border", "0")
            Me.YoutubeScreenTV.Src = TV.VideoUrl
            Me.YoutubeScreenTV.Visible = True
            Me.VideoPosterImgBtn.Visible = False

        Else

            'message to the user
            Response.Write("Error")
        End If
    End Sub
End Class