﻿Public Class _default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            Dim videoImageClass As String = "videoimage"
            Dim videoDescriptionClass As String = "videodescription"

            Dim createlist As New List(Of YouTubeTv.CreatePlayList)

            Dim video1 As New YouTubeTv.CreatePlayList()
            Dim video2 As New YouTubeTv.CreatePlayList()
            Dim video3 As New YouTubeTv.CreatePlayList()
            Dim video4 As New YouTubeTv.CreatePlayList()
            Dim video5 As New YouTubeTv.CreatePlayList()
            Dim video6 As New YouTubeTv.CreatePlayList()
            Dim video7 As New YouTubeTv.CreatePlayList()
            Dim video8 As New YouTubeTv.CreatePlayList()

            video1.VideoUrl = "http://youtu.be/jHCY_YV7Ebs"
            video1.Description = "<b>(by Guru Josh Project/Klass)</b> Infinity" & "<a href='" & video1.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video1.DescriptionCSS = videoDescriptionClass
            video1.ImageCSS = videoImageClass

            video2.VideoUrl = "http://youtu.be/0SdqOC8NA7s"
            video2.Description = "<b> Gigi D'Agostino </b>Another Way" & "<a href='" & video2.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video2.DescriptionCSS = videoDescriptionClass
            video2.ImageCSS = videoImageClass

            video3.VideoUrl = "http://youtu.be/5W_wd9Qf0IE"
            video3.Description = "<b>Code Monkey AMV</b> This AMV features the song Code Monkey by Jonathan Coulton, using footage from the anime Black Heaven." & "<a href='" + video3.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video3.DescriptionCSS = videoDescriptionClass
            video3.ImageCSS = videoImageClass

            video4.VideoUrl = "http://youtu.be/v9hdMSr6Duc"
            video4.Description = "<b>Ace of Base</b> Beautiful Life" & "<a href='" & video4.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video4.DescriptionCSS = videoDescriptionClass
            video4.ImageCSS = videoImageClass

            video5.VideoUrl = "http://youtu.be/ZyhrYis509A"
            video5.Description = "<b>Aqua</b> - Barbie Girl" & "<a href='" & video5.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video5.DescriptionCSS = videoDescriptionClass
            video5.ImageCSS = videoImageClass

            video6.VideoUrl = "http://youtu.be/ZbUENJ5FjBk"
            video6.Description = "<b>Milli Vanilli</b> Girl I'm Gonna Miss You" & "<a href='" & video6.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video6.DescriptionCSS = videoDescriptionClass
            video6.ImageCSS = videoImageClass

            video7.VideoUrl = "http://youtu.be/fUis9yny_lI"
            video7.Description = "<b>Berlin </b> Take My Breathe Away theme from Top Gun with Lyrics" & "<a href='" + video7.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video7.DescriptionCSS = videoDescriptionClass
            video7.ImageCSS = videoImageClass

            video8.VideoUrl = "http://youtu.be/JkK8g6FMEXE"
            video8.Description = "<b>Aerosmith</b> I Don't Want to Miss a Thing" & "<a href='" & video8.VideoUrl & "' target='_blank'> see on web</a><br/><br/>"
            video8.DescriptionCSS = videoDescriptionClass
            video8.ImageCSS = videoImageClass

            createlist.Add(video1)
            createlist.Add(video2)
            createlist.Add(video3)
            createlist.Add(video4)
            createlist.Add(video5)
            createlist.Add(video6)
            createlist.Add(video7)
            createlist.Add(video8)

            Dim createplaylist As New YouTubeTv.PlayList()
            createplaylist.Load(Me.playlistContainerdv, Me.YoutubeScreenTV, createlist)
            Me.videoCountlbl.Text = Convert.ToString(createlist.Count) + " Videos on list"


        Catch ex As YouTubeTv.Exception

            Response.Write(ex.Message)

        End Try

    End Sub

End Class